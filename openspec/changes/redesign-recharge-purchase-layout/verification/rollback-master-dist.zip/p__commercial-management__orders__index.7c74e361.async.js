"use strict";(self.webpackChunkant_short_tv_frontend=self.webpackChunkant_short_tv_frontend||[]).push([[5389],{99635:function(he,D,r){r.r(D),r.d(D,{default:function(){return le}});var K=r(62120),h=r.n(K),W=r(79319),P=r.n(W),U=r(44983),S=r.n(U),Q=r(49975),c=r.n(Q),J=r(62650),q=r(26646),v=r(76891),C=r(64674),p=r(55157),O=r(94710),ee=r(90225),ne=r(35184),x=r(64052),te=r(70925),T=r(91625),re=function(n){return(0,v.request)("/api/platform/commercial/orders",{params:n})},ae=function(n){return(0,v.request)("/api/platform/commercial/orders/".concat(n))},t=r(60358),A,I,L,V,B,G,z,M,k,Z,$=function(n){var e;return(e=Object({PENDING_PAYMENT:"\u5F85\u652F\u4ED8",PAID:"\u5DF2\u652F\u4ED8",ENTITLEMENT_PENDING:"\u6743\u76CA\u53D1\u653E\u4E2D",COMPLETED:"\u5DF2\u5B8C\u6210",CLOSED:"\u5DF2\u5173\u95ED",PAYMENT_EXCEPTION:"\u652F\u4ED8\u5F02\u5E38"})[n!=null?n:"PENDING_PAYMENT"])!==null&&e!==void 0?e:"-"},F=function(n){return n==="COMPLETED"?"success":n==="PAYMENT_EXCEPTION"?"error":n==="PENDING_PAYMENT"?"warning":"default"},X=function(n){return n==="SUBSCRIPTION"?"\u4F1A\u5458\u8BA2\u9605":n==="POINT_PACKAGE"?"\u79EF\u5206\u5305":"-"},_=function(n){var e=n?new Date(n):void 0;return e&&!Number.isNaN(e.getTime())?e.toLocaleString("zh-CN",{hour12:!1}):"-"},oe=(0,te.kc)(function(m){var n=m.css,e=m.token;return{drawerBody:n(A||(A=c()([`
    padding: 0;
  `]))),summary:n(I||(I=c()([`
    padding: `,"px ","px ",`px;
    background: `,`;
    border-bottom: 1px solid `,`;
  `])),e.paddingLG,e.paddingLG,e.padding,e.colorFillQuaternary,e.colorBorderSecondary),orderNumber:n(L||(L=c()([`
    display: block;
    color: `,`;
    font-family: `,`;
    font-size: `,`px;
    overflow-wrap: anywhere;
  `])),e.colorTextDescription,e.fontFamilyCode,e.fontSizeSM),summaryMetrics:n(V||(V=c()([`
    display: flex;
    align-items: end;
    justify-content: space-between;
    gap: `,`px;
    margin-top: `,`px;
  `])),e.marginLG,e.marginLG),metricLabel:n(B||(B=c()([`
    color: `,`;
    font-size: `,`px;
  `])),e.colorTextDescription,e.fontSizeSM),amount:n(G||(G=c()([`
    margin-top: `,`px;
    color: `,`;
    font-size: `,`px;
    font-weight: `,`;
    line-height: `,`;
  `])),e.marginXXS,e.colorText,e.fontSizeHeading2,e.fontWeightStrong,e.lineHeightHeading2),currency:n(z||(z=c()([`
    margin-left: `,`px;
    color: `,`;
    font-size: `,`px;
    font-weight: `,`;
  `])),e.marginXXS,e.colorTextSecondary,e.fontSizeSM,e.fontWeightStrong),status:n(M||(M=c()([`
    text-align: right;
  `]))),content:n(k||(k=c()([`
    padding: `,`px;
  `])),e.paddingLG),group:n(Z||(Z=c()([`
    & + & {
      margin-top: `,`px;
      padding-top: `,`px;
      border-top: 1px solid `,`;
    }

    .ant-descriptions-title {
      margin-bottom: `,`px;
      font-size: `,`px;
    }

    .ant-descriptions-item-label {
      color: `,`;
    }

    .ant-descriptions-item-content {
      color: `,`;
      overflow-wrap: anywhere;
    }
  `])),e.marginXL,e.paddingLG,e.colorBorderSecondary,e.marginLG,e.fontSizeLG,e.colorTextDescription,e.colorTextSecondary)}}),se=function(){var n,e,g,y,N,b,j,E,de=(0,v.useAccess)(),ie=oe(),d=ie.styles,ue=(0,T.useRef)(void 0),ce=(0,T.useState)(),R=S()(ce,2),a=R[0],Y=R[1],me=(0,T.useState)(!1),w=S()(me,2),_e=w[0],H=w[1],pe=function(){var u=P()(h()().mark(function s(l){var i;return h()().wrap(function(o){for(;;)switch(o.prev=o.next){case 0:return H(!0),o.prev=1,o.next=4,ae(l);case 4:i=o.sent,Y(i.data);case 6:return o.prev=6,H(!1),o.finish(6);case 9:case"end":return o.stop()}},s,null,[[1,,6,9]])}));return function(l){return u.apply(this,arguments)}}(),fe=[{title:"\u8BA2\u5355\u53F7\u6216\u79DF\u6237\u540D\u79F0",dataIndex:"keyword",hideInTable:!0},{title:"\u8BA2\u5355\u72B6\u6001",dataIndex:"status",hideInTable:!0,valueType:"select",valueEnum:{PENDING_PAYMENT:{text:"\u5F85\u652F\u4ED8"},PAID:{text:"\u5DF2\u652F\u4ED8"},ENTITLEMENT_PENDING:{text:"\u6743\u76CA\u53D1\u653E\u4E2D"},COMPLETED:{text:"\u5DF2\u5B8C\u6210"},CLOSED:{text:"\u5DF2\u5173\u95ED"},PAYMENT_EXCEPTION:{text:"\u652F\u4ED8\u5F02\u5E38"}}},{title:"\u5957\u9910\u7C7B\u578B",dataIndex:"packageType",hideInTable:!0,valueType:"select",valueEnum:{POINT_PACKAGE:{text:"\u79EF\u5206\u5305"},SUBSCRIPTION:{text:"\u4F1A\u5458\u8BA2\u9605"}}},{title:"\u8BA2\u5355\u53F7",dataIndex:"merchantOrderNo",search:!1},{title:"\u79DF\u6237",search:!1,render:function(s,l){var i,f;return(0,t.jsxs)(C.Z,{orientation:"vertical",size:0,children:[(0,t.jsx)(p.Z.Text,{strong:!0,children:(i=l.tenantName)!==null&&i!==void 0?i:"-"}),(0,t.jsx)(p.Z.Text,{type:"secondary",children:(f=l.tenantCode)!==null&&f!==void 0?f:"-"})]})}},{title:"\u5957\u9910",search:!1,render:function(s,l){return(0,t.jsxs)(C.Z,{orientation:"vertical",size:0,children:[(0,t.jsx)(p.Z.Text,{children:l.packageName}),(0,t.jsxs)(p.Z.Text,{type:"secondary",children:["V",l.packageVersionNo," \xB7 ",X(l.packageType)]})]})}},{title:"\u5B9E\u4ED8\u91D1\u989D",search:!1,render:function(s,l){return"".concat(l.amount," ").concat(l.currency)}},{title:"\u8BA2\u5355\u72B6\u6001",dataIndex:"status",search:!1,render:function(s){return(0,t.jsx)(O.Z,{color:F(s),children:$(s)})}},{title:"\u652F\u4ED8\u65F6\u95F4",dataIndex:"paidAt",search:!1,render:function(s){return _(s)}},{title:"\u521B\u5EFA\u65F6\u95F4",dataIndex:"createdAt",search:!1,render:function(s){return _(s)}},{title:"\u64CD\u4F5C",valueType:"option",search:!1,render:function(s,l){return(0,t.jsx)(ee.ZP,{type:"link",onClick:function(){return void pe(l.id)},children:"\u67E5\u770B\u8BE6\u60C5"})}}];return(0,t.jsxs)(J._z,{title:"\u8BA2\u5355\u7BA1\u7406",children:[(0,t.jsx)(q.Z,{actionRef:ue,rowKey:"id",columns:fe,search:{labelWidth:"auto"},pagination:{defaultPageSize:20,showSizeChanger:!0},request:function(){var u=P()(h()().mark(function s(l){var i;return h()().wrap(function(o){for(;;)switch(o.prev=o.next){case 0:if(de.canViewCommercialOrders){o.next=2;break}return o.abrupt("return",{data:[],total:0,success:!1});case 2:return o.next=4,re(l);case 4:return i=o.sent,o.abrupt("return",{data:i.data.records,total:i.data.total,success:i.success});case 6:case"end":return o.stop()}},s)}));return function(s){return u.apply(this,arguments)}}()}),(0,t.jsx)(ne.Z,{title:"\u8BA2\u5355\u8BE6\u60C5",open:!!a,loading:_e,size:"large",destroyOnHidden:!0,classNames:{body:d.drawerBody},onClose:function(){return Y(void 0)},children:a&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("section",{className:d.summary,"aria-label":"\u8BA2\u5355\u6458\u8981",children:[(0,t.jsx)(p.Z.Text,{className:d.orderNumber,children:a.merchantOrderNo}),(0,t.jsxs)("div",{className:d.summaryMetrics,children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("div",{className:d.metricLabel,children:"\u5B9E\u4ED8\u91D1\u989D"}),(0,t.jsxs)("div",{className:d.amount,children:[a.amount,(0,t.jsx)("span",{className:d.currency,children:a.currency})]})]}),(0,t.jsxs)("div",{className:d.status,children:[(0,t.jsx)("div",{className:d.metricLabel,children:"\u8BA2\u5355\u72B6\u6001"}),(0,t.jsx)(O.Z,{color:F(a.status),children:$(a.status)})]})]})]}),(0,t.jsxs)("div",{className:d.content,children:[(0,t.jsx)(x.Z,{className:d.group,title:"\u8BA2\u5355\u4FE1\u606F",column:{xs:1,sm:2},items:[{key:"tenant",label:"\u79DF\u6237",children:(n=a.tenantName)!==null&&n!==void 0?n:"-"},{key:"createdAt",label:"\u521B\u5EFA\u65F6\u95F4",children:_(a.createdAt)},{key:"completedAt",label:"\u5B8C\u6210\u65F6\u95F4",children:_(a.completedAt)}]}),(0,t.jsx)(x.Z,{className:d.group,title:"\u5957\u9910\u7248\u672C",column:{xs:1,sm:2},items:[{key:"packageName",label:"\u5957\u9910\u540D\u79F0",children:a.packageName},{key:"version",label:"\u7248\u672C",children:"V".concat(a.packageVersionNo)},{key:"type",label:"\u5957\u9910\u7C7B\u578B",children:X(a.packageType)},{key:"expiresAt",label:"\u652F\u4ED8\u622A\u6B62\u65F6\u95F4",children:_(a.expiresAt)}]}),(0,t.jsx)(x.Z,{className:d.group,title:"\u652F\u4ED8\u4FE1\u606F",column:{xs:1,sm:2},items:[{key:"provider",label:"\u652F\u4ED8\u6E20\u9053",children:(e=(g=a.payment)===null||g===void 0?void 0:g.provider)!==null&&e!==void 0?e:"-"},{key:"paymentStatus",label:"\u652F\u4ED8\u72B6\u6001",children:(y=(N=a.payment)===null||N===void 0?void 0:N.status)!==null&&y!==void 0?y:"-"},{key:"tradeNo",label:"\u5FAE\u4FE1\u652F\u4ED8\u5355\u53F7",children:(b=(j=a.payment)===null||j===void 0?void 0:j.providerTradeNo)!==null&&b!==void 0?b:"-"},{key:"paidAt",label:"\u652F\u4ED8\u65F6\u95F4",children:_((E=a.payment)===null||E===void 0?void 0:E.paidAt)}]})]})]})})]})},le=se}}]);
