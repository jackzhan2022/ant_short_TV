"use strict";(self.webpackChunkant_short_tv_frontend=self.webpackChunkant_short_tv_frontend||[]).push([[3061],{12948:function(Ie,I,n){n.r(I),n.d(I,{default:function(){return ge}});var W=n(90567),X=n.n(W),w=n(25257),P=n.n(w),J=n(44983),p=n.n(J),Q=n(86032),Y=n(62650),$=n(82830),q=n(18045),ee=n(5584),ne=n(68376),te=n(71113),re=n(99772),se=n(76895),M=n(31994),ae=n(34444),a=n(91625),oe=n(8907),le=n(19997),D,de=(D={NODE_ENV:"production",PUBLIC_PATH:"/"}.CHAT_API_URL)!==null&&D!==void 0?D:"https://api.x.ant.design/api/big_model_glm-4.5-flash",ie=function(){return new oe.Z({request:(0,le.ZP)(de,{manual:!0,params:{model:"glm-4.5-flash",stream:!0}})})},_e=n(49975),l=n.n(_e),ue=n(70925),N,R,Z,E,O,L,B,F,z=(0,ue.kc)(function(u){var r=u.css,e=u.token;return{layout:r(N||(N=l()([`
    display: flex;
    flex: 1;
    overflow: hidden;
  `]))),sidebar:r(R||(R=l()([`
    width: 260px;
    background: `,`;
    border-right: 1px solid `,`;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  `])),e.colorBgContainer,e.colorBorderSecondary),main:r(Z||(Z=l()([`
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    min-width: 0;
    background: `,`;
  `])),e.colorBgContainer),messages:r(E||(E=l()([`
    flex: 1;
    overflow-y: auto;
    padding: `,`px;
    display: flex;
    flex-direction: column;
    align-items: center;

    > * {
      width: 100%;
    }
  `])),e.paddingMD),footer:r(O||(O=l()([`
    padding: `,`px;
    border-top: 1px solid `,`;
    display: flex;
    justify-content: center;
  `])),e.paddingMD,e.colorBorderSecondary),footerCenter:r(L||(L=l()([`
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: `,`px;
    gap: 32px;
    margin-top: -10%;
  `])),e.paddingLG),welcomeTitle:r(B||(B=l()([`
    font-size: 32px;
    font-weight: 600;
    color: `,`;
    text-align: center;
  `])),e.colorText),cursor:r(F||(F=l()([`
    animation: chatbot-blink 0.8s step-end infinite;

    @keyframes chatbot-blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0; }
    }
  `])))}}),t=n(60358),C="\u{1F916} \u4F60\u597D\uFF0C\u6709\u4EC0\u4E48\u53EF\u4EE5\u5E2E\u4F60\uFF1F",ce=function(){var r=z(),e=r.styles,h=(0,a.useState)(0),d=p()(h,2),i=d[0],c=d[1],j=i>=C.length;return(0,a.useEffect)(function(){var f=setInterval(function(){c(function(v){return v>=C.length?(clearInterval(f),v):v+1})},80);return function(){return clearInterval(f)}},[]),(0,t.jsxs)(t.Fragment,{children:[C.slice(0,i),!j&&(0,t.jsx)("span",{className:e.cursor,children:"|"})]})},me=function(r){var e=r.content,h=r.role;if(h!=="assistant")return{role:"user",content:e};var d=e.trimStart(),i=d.match(/^<think>([\s\S]*?)<\/think>([\s\S]*)$/);if(i)return{role:"assistant",thinkContent:i[1],content:i[2].trimStart()};var c=d.match(/^<think>([\s\S]*)$/);return c?{role:"assistant",thinkContent:c[1],content:""}:{role:"assistant",content:e}},fe={hasNextChunk:!0,enableAnimation:!0},he={hasNextChunk:!1,enableAnimation:!0},ve={user:{placement:"end",avatar:(0,t.jsx)(M.Z,{icon:(0,t.jsx)(Q.Z,{})})},ai:{placement:"start",avatar:(0,t.jsx)(M.Z,{style:{background:"transparent",fontSize:22,display:"flex",alignItems:"center",justifyContent:"center"},children:"\u{1F916}"}),typing:{effect:"typing",step:2,interval:20},contentRender:function(r,e){if(!(e!=null&&e.loading||!r))return(0,t.jsx)(re.Z,{streaming:(e==null?void 0:e.status)==="updating"?fe:he,children:r})}}},pe=function(){var r=z(),e=r.styles,h=(0,a.useRef)(0),d=(0,a.useCallback)(function(){return"conv-".concat(++h.current)},[]),i=(0,a.useState)([{key:"default",label:"\u{1F4AC} \u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0},{key:"preset-1",label:"\u{1F9E9} Ant Design \u7684 Form \u8868\u5355\u5982\u4F55\u505A\u8054\u52A8\u6821\u9A8C\uFF1F",group:"\u4ECA\u5929"},{key:"preset-2",label:"\u{1F4CB} ProTable \u5982\u4F55\u81EA\u5B9A\u4E49\u5DE5\u5177\u680F\u6309\u94AE\uFF1F",group:"\u4ECA\u5929"},{key:"preset-3",label:"\u{1F3A8} \u5982\u4F55\u7528 antd-style \u5B9E\u73B0\u6697\u8272\u4E3B\u9898\u5207\u6362\uFF1F",group:"\u6628\u5929"},{key:"preset-4",label:"\u{1F5C2}\uFE0F ProLayout \u4FA7\u8FB9\u83DC\u5355\u5982\u4F55\u52A8\u6001\u751F\u6210\uFF1F",group:"\u6628\u5929"},{key:"preset-5",label:"\u{1F4CA} Ant Design Charts \u6298\u7EBF\u56FE\u6570\u636E\u683C\u5F0F",group:"\u6628\u5929"},{key:"preset-6",label:"\u5267\u667A\u521B\u5982\u4F55\u63A5\u5165\u540E\u7AEF\u6743\u9650\u7CFB\u7EDF\uFF1F",group:"\u66F4\u65E9"},{key:"preset-7",label:"\u{1F50D} ProForm \u4E2D Select \u8FDC\u7A0B\u641C\u7D22\u600E\u4E48\u5B9E\u73B0\uFF1F",group:"\u66F4\u65E9"},{key:"preset-8",label:"\u2699\uFE0F Ant Design Token \u5B9A\u5236\u4E3B\u9898\u6700\u4F73\u5B9E\u8DF5",group:"\u66F4\u65E9"}]),c=p()(i,2),j=c[0],f=c[1],v=(0,a.useState)("default"),H=p()(v,2),g=H[0],x=H[1],xe=(0,a.useState)(""),K=p()(xe,2),ye=K[0],U=K[1],be=(0,a.useMemo)(function(){return ie()},[]),y=(0,se.Z)({provider:be,conversationKey:g,parser:me,requestPlaceholder:{role:"assistant",content:""}}),Te=y.onRequest,De=y.abort,Ce=y.isRequesting,S=y.parsedMessages,je=function(s){U(""),f(function(_){return _.map(function(o){return o.key===g&&o.isDraft?P()(P()({},o),{},{label:s.slice(0,20),isDraft:!1}):o})}),Te({messages:[{role:"user",content:s}]})},Se=function(){var s=d();f(function(_){return[{key:s,label:"\u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0}].concat(X()(_))}),x(s)},ke=(0,a.useMemo)(function(){return S.map(function(m){var s=m.message,_=s.role==="assistant",o=s.role==="assistant"?s.thinkContent:void 0,b={key:m.id,role:_?"ai":"user",content:s.content,loading:_&&m.status==="loading",status:m.status};return _&&o&&(b.header=(0,t.jsx)($.Z,{children:o})),b})},[S]),k=S.length>0;return(0,t.jsx)(Y._z,{ghost:!0,childrenContentStyle:{paddingBlock:0,height:"calc(100vh - 160px)",display:"flex",flexDirection:"column",overflow:"hidden"},children:(0,t.jsx)(ae.Z,{variant:"borderless",style:{height:"100%",display:"flex",flexDirection:"column",overflow:"hidden"},styles:{body:{flex:1,padding:0,overflow:"hidden",display:"flex",flexDirection:"column"}},children:(0,t.jsx)(q.ZP,{children:(0,t.jsxs)("div",{className:e.layout,children:[(0,t.jsx)("div",{className:e.sidebar,children:(0,t.jsx)(ee.Z,{items:j,activeKey:g,onActiveChange:x,groupable:!0,menu:function(s){return{items:[{key:"delete",label:"\u5220\u9664",danger:!0}],onClick:function(o){var b=o.key;b==="delete"&&f(function(Ve){var T=Ve.filter(function(Ae){return Ae.key!==s.key});if(T.length===0){var G=d();T.push({key:G,label:"\u{1F4AC} \u65B0\u5BF9\u8BDD",group:"\u4ECA\u5929",isDraft:!0}),x(G)}else if(g===s.key){var V,A;x((V=(A=T[0])===null||A===void 0?void 0:A.key)!==null&&V!==void 0?V:"")}return T})}}},creation:{onClick:Se,label:"\u65B0\u5EFA\u5BF9\u8BDD"}})}),(0,t.jsxs)("div",{className:e.main,children:[k&&(0,t.jsx)("div",{className:e.messages,children:(0,t.jsx)(ne.Z.List,{items:ke,role:ve,autoScroll:!0,styles:{root:{maxWidth:940}}})}),(0,t.jsxs)("div",{className:k?e.footer:e.footerCenter,children:[!k&&(0,t.jsx)("div",{className:e.welcomeTitle,children:(0,t.jsx)(ce,{})}),(0,t.jsx)(te.Z,{value:ye,onChange:U,loading:Ce,onSubmit:je,onCancel:De,placeholder:"\u8F93\u5165\u6D88\u606F\uFF0C\u6309 Enter \u53D1\u9001...",autoSize:{minRows:4,maxRows:8},style:{maxWidth:940,width:"100%"},styles:{input:{paddingBlock:0}}})]})]})]})})})})},ge=pe}}]);
